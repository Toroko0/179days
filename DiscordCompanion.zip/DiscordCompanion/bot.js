const { 
  Client, 
  GatewayIntentBits, 
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  SlashCommandBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  Collection
} = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
const { format, addDays, isWithinInterval, eachDayOfInterval, differenceInDays, startOfDay, setHours, isSameDay } = require('date-fns');
const { formatInTimeZone, zonedTimeToUtc } = require('date-fns-tz');
require('dotenv').config();

// Filter options for holiday patterns (unchanged)
const HOLIDAY_PATTERNS = {
  'friday-saturday': ['5', '6'],  // Friday and Saturday
  'thursday-friday': ['4', '5'],  // Thursday and Friday
};

// Token validation (unchanged)
const token = process.env.DISCORD_TOKEN ? process.env.DISCORD_TOKEN.trim() : null;
if (!token) {
  console.error('Discord token is missing! Please make sure DISCORD_TOKEN is set in your environment variables.');
  process.exit(1);
}

// Create client (unchanged)
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.DirectMessages
  ]
});

// Initialize database (unchanged)
const db = new sqlite3.Database('./worlds.db');

// Update the database schema with last_update_date column
db.serialize(() => {
  // Create the main table if it doesn't exist
  db.run(`CREATE TABLE IF NOT EXISTS worlds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    world_name TEXT,
    days_owned INTEGER,
    added_date TEXT,
    added_by TEXT,
    user_id TEXT,
    is_public INTEGER DEFAULT 0,
    last_update_date TEXT,
    UNIQUE(world_name, user_id)
  )`);

  // Add last_update_date column if it doesn't exist
  db.all("PRAGMA table_info(worlds)", (err, rows) => {
    if (err) {
      console.error('Error checking table schema:', err);
      return;
    }

    if (!rows.some(row => row.name === 'last_update_date')) {
      db.run("ALTER TABLE worlds ADD COLUMN last_update_date TEXT", (err) => {
        if (err) {
          console.error('Error adding last_update_date column:', err);
        } else {
          console.log('Added last_update_date column successfully');
          // Initialize last_update_date for existing records
          db.run("UPDATE worlds SET last_update_date = added_date WHERE last_update_date IS NULL", (err) => {
            if (err) {
              console.error('Error initializing last_update_date:', err);
            } else {
              console.log('Initialized last_update_date for existing records');
            }
          });
        }
      });
    }
  });
});

// Only register the /list command (unchanged)
const commands = [
  new SlashCommandBuilder()
    .setName('list')
    .setDescription('View your tracked worlds')
].map(command => command.toJSON());

// When the client is ready, register the /list command (unchanged)
client.once('ready', async () => {
  console.log(`Successfully logged in as ${client.user.tag}`);

  try {
    console.log('Started refreshing application (/) commands.');
    await client.application.commands.set(commands);
    console.log('Successfully reloaded application (/) commands.');

    // Set up daily world updates (modified to include cleanup)
    async function checkAndUpdateWorlds() {
      try {
        await updateWorldDays();
        await cleanupExpiredWorlds();
        console.log('Daily world update and cleanup completed');
      } catch (error) {
        console.error('Error in daily update:', error);
      }
    }

    // Run update check every hour (unchanged)
    setInterval(checkAndUpdateWorlds, 60 * 60 * 1000);
    // Run initial check (unchanged)
    await checkAndUpdateWorlds();
  } catch (error) {
    console.error('Error in startup:', error);
  }
});

// Format dates consistently (unchanged)
function formatDate(date) {
  return format(date, 'd-MMM');
}

// Get the current date (unchanged)
function getCurrentDate() {
  return new Date();
}

// Update timezone functions
function getCurrentDateInTimeZone() {
  const now = new Date();
  return new Date(formatInTimeZone(now, 'America/New_York', 'yyyy-MM-dd HH:mm:ssXXX'));
}

function formatDateInTimeZone(date) {
  return formatInTimeZone(date, 'America/New_York', 'd-MMM');
}


// Calculate expiration date (unchanged)
function calculateExpirationDate(daysOwned) {
  const daysLeft = 180 - daysOwned;
  return addDays(getCurrentDate(), daysLeft);
}

// Count the number of letters in a world name (unchanged)
function countLetters(worldName) {
  // Remove special characters like "+" for buy+/sell+ prefixes
  return worldName.replace(/[^a-zA-Z0-9]/g, '').length;
}

// Update the world days update function with proper timezone handling
async function updateWorldDays() {
  return new Promise((resolve, reject) => {
    const currentDate = getCurrentDateInTimeZone();
    const currentDateStr = format(currentDate, 'yyyy-MM-dd');
    console.log(`Checking for world updates (UTC-5): ${currentDateStr}`);

    const query = `
      SELECT * FROM worlds 
      WHERE (last_update_date < ? OR last_update_date IS NULL)
        AND days_owned < 180
    `;

    db.all(query, [currentDateStr], async (err, worlds) => {
      if (err) {
        console.error('Error fetching worlds for update:', err);
        reject(err);
        return;
      }

      console.log(`Found ${worlds.length} worlds to update`);

      try {
        for (const world of worlds) {
          await new Promise((resolveUpdate) => {
            const newDaysOwned = Math.min(180, world.days_owned + 1);
            console.log(`Updating world ${world.world_name}: ${world.days_owned} -> ${newDaysOwned} days`);

            db.run(
              'UPDATE worlds SET days_owned = ?, last_update_date = ? WHERE id = ?',
              [newDaysOwned, currentDateStr, world.id],
              function(err) {
                if (err) {
                  console.error(`Error updating world ${world.world_name}:`, err);
                } else {
                  console.log(`Successfully updated world ${world.world_name}`);
                }
                resolveUpdate();
              }
            );
          });
        }
        console.log('Daily world update completed successfully');
        resolve();
      } catch (error) {
        console.error('Error in world update loop:', error);
        reject(error);
      }
    });
  });
}

// Add a world to the database (unchanged)
function addWorld(worldName, daysOwned, addedBy, userId, makePublic = 0) {
  return new Promise((resolve, reject) => {
    const addedDate = formatDate(getCurrentDate());

    db.run(
      'INSERT OR REPLACE INTO worlds (world_name, days_owned, added_date, added_by, user_id, is_public, last_update_date) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [worldName, daysOwned, addedDate, addedBy, userId, makePublic, format(getCurrentDate(), 'yyyy-MM-dd')],
      function(err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      }
    );
  });
}

// Remove a world from the database (unchanged)
function removeWorld(worldName, userId) {
  return new Promise((resolve, reject) => {
    db.run('DELETE FROM worlds WHERE world_name = ? AND user_id = ?', [worldName, userId], function(err) {
      if (err) {
        reject(err);
      } else {
        resolve(this.changes > 0);
      }
    });
  });
}

// Get worlds with calculated fields (unchanged except for filter application)
function getWorlds(userId = null, showPublic = false, filter = null) {
  return new Promise((resolve, reject) => {
    let query = `SELECT * FROM worlds`;
    let conditions = [];
    let params = [];

    if (userId !== null) {
      conditions.push('user_id = ?');
      params.push(userId);
    }

    if (showPublic) {
      conditions.push('is_public = 1');
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }

    db.all(query, params, (err, rows) => {
      if (err) {
        reject(err);
      } else {
        const currentDate = getCurrentDateInTimeZone();
        const processedRows = rows.map(row => {
          const daysOwned = parseInt(row.days_owned);
          const daysLeft = 180 - daysOwned;
          const expirationDate = addDays(startOfDay(currentDate), daysLeft);
          const letterCount = countLetters(row.world_name);

          return {
            ...row,
            days_left: daysLeft,
            expiration_date: formatDateInTimeZone(expirationDate),
            letter_count: letterCount,
            expires_today: daysLeft === 0 || isSameDay(expirationDate, currentDate)
          };
        });

        // Filter if needed
        let filteredRows = processedRows;
        if (filter) {
          filteredRows = getFilteredWorlds(processedRows, filter.type, filter.value);
        }

        // Sort by expiration (urgent first) then by days owned
        filteredRows.sort((a, b) => {
          if (a.expires_today && !b.expires_today) return -1;
          if (!a.expires_today && b.expires_today) return 1;
          return b.days_owned - a.days_owned;
        });

        resolve(filteredRows);
      }
    });
  });
}

// Update a world's public status with ownership check
function updateWorldPublicStatus(worldName, userId, makePublic) {
  return new Promise((resolve, reject) => {
    console.log(`Attempting to ${makePublic ? 'share' : 'unshare'} world "${worldName}" by user ${userId}`);
    // First check if the user owns the world
    db.get(
      'SELECT * FROM worlds WHERE world_name = ? AND added_by = (SELECT added_by FROM worlds WHERE world_name = ? AND user_id = ?)',
      [worldName, worldName, userId],
      (err, world) => {
        if (err) {
          console.error(`Database error during ownership check: ${err.message}`);
          reject(err);
          return;
        }

        if (!world) {
          console.log(`Unauthorized attempt to modify world "${worldName}" by user ${userId}`);
          reject(new Error('You can only modify worlds that you added'));
          return;
        }

        console.log(`Authorized modification of world "${worldName}" by owner ${userId}`);
        db.run(
          'UPDATE worlds SET is_public = ? WHERE world_name = ? AND user_id = ?',
          [makePublic, worldName, userId],
          function(err) {
            if (err) {
              console.error(`Error updating world status: ${err.message}`);
              reject(err);
            } else {
              console.log(`Successfully ${makePublic ? 'shared' : 'unshared'} world "${worldName}"`);
              resolve(this.changes > 0);
            }
          }
        );
      }
    );
  });
}

// Modify the existing getWorldStats function to include BUY+ and SELL+ categories (unchanged)
function getWorldStats(userId = null, showPublic = false) {
  return new Promise((resolve, reject) => {
    let query = 'SELECT world_name FROM worlds';
    let params = [];
    let conditions = [];

    if (userId !== null) {
      conditions.push('user_id = ?');
      params.push(userId);
    }

    if (showPublic) {
      conditions.push('is_public = 1');
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }

    db.all(query, params, (err, rows) => {
      if (err) {
        reject(err);
      } else {
        const stats = {
          '1letter': 0,
          '2letter': 0,
          '3letter': 0,
          '4letter': 0,
          'buy': 0,
          'sell': 0,
          'other': 0,
          'total': rows.length
        };

        rows.forEach(row => {
          const worldName = row.world_name.toUpperCase();
          const letterCount = countLetters(worldName);

          if (worldName.startsWith('BUY')) {
            stats.buy++;
          } else if (worldName.startsWith('SELL')) {
            stats.sell++;
          } else if (letterCount >= 1 && letterCount <= 4) {
            stats[`${letterCount}letter`]++;
          } else {
            stats.other++;
          }
        });

        resolve(stats);
      }
    });
  });
}


// Update leaderboard to only count public worlds
function getLeaderboardData(timeframe = 'all-time') {
  return new Promise((resolve, reject) => {
    let query = `
      SELECT added_by, COUNT(*) as world_count
      FROM worlds
      WHERE is_public = 1
    `;

    const params = [];
    const today = new Date();

    switch (timeframe) {
      case 'month':
        query += ` AND strftime('%Y-%m', added_date) = strftime('%Y-%m', ?)`;
        params.push(format(today, 'yyyy-MM-dd'));
        break;
      case 'week':
        query += ` AND julianday(added_date) >= julianday(?) - 7`;
        params.push(format(today, 'yyyy-MM-dd'));
        break;
      case 'today':
        query += ` AND date(added_date) = date(?)`;
        params.push(format(today, 'yyyy-MM-dd'));
        break;
    }

    query += `
      GROUP BY added_by
      ORDER BY world_count DESC
      LIMIT 10
    `;

    db.all(query, params, (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
}

// Add a separate function for handling command buttons (unchanged)
async function handleCommandButton(interaction, type) {
  try {
    switch(type) {
      case 'stats': {
        const listType = interaction.message.content.toLowerCase().includes('public') ? 'public' : 'private';
        const userId = listType === 'public' ? null :interaction.user.id;
        const stats = await getWorldStats(userId, listType === 'public');

        const statsEmbed = new EmbedBuilder()
          .setTitle(`📊 ${listType.toUpperCase()} LIST STATISTICS`)
          .setColor(0x0099FF)
          .addFields(
            { name: '📝 Letter Count Distribution', value: 
              `1️⃣ One Letter: ${stats['1letter']}\n` +
              `2️⃣ Two Letters: ${stats['2letter']}\n` +
              `3️⃣ Three Letters: ${stats['3letter']}\n` +`4️⃣ Four Letters:${stats['4letter']}`
            },
            { name: '🏷️ Special Categories', value:
              `💰 BUY+ Worlds: ${stats['buy']}\n` +
              `🏪 SELL+ Worlds: ${stats['sell']}\n` +
              `📦 Other Worlds: ${stats['other']}`
            },
            { name: '📊 Total Worlds', value: `${stats.total} worlds tracked` }
          )
          .setTimestamp()
          .setFooter({ text: 'Updated Statistics' });

        await interaction.editReply({
          embeds: [statsEmbed],
          components: interaction.message.components
        });
        break;
      }
      case 'leaderboard': {
        const leaderboardData = await getLeaderboardData('all-time');
        const leaderboardEmbed = new EmbedBuilder()
          .setTitle('🏆 TOP CONTRIBUTORS')
          .setColor(0xFFD700)
          .setDescription(
            leaderboardData.map((row, index) => {
              const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '👥';
              const username = row.added_by.split('#')[0];
              return `${medal} **${index + 1}.** ${username} - ${row.world_count} worlds`;
            }).join('\n')
          )
          .setFooter({ text: 'All Time Stats • Use buttons below to view different periods' });

        await interaction.editReply({
          embeds: [leaderboardEmbed],
          components: interaction.message.components
        });
        break;
      }
      case 'expiring': {
        const worlds = await getWorlds(interaction.user.id);
        const todayExpiring = worlds.filter(world => world.expires_today);

        if (todayExpiring.length === 0) {
          await interaction.editReply({
            embeds: [createInfoEmbed('No Expiring Worlds', 'No worlds are expiring today.')],
            components: interaction.message.components
          });
        } else {
          const expiringTable = formatWorldsTable(todayExpiring, 1, 10, "expiring today");
          await interaction.editReply({
            content: expiringTable,
            components: [
              createPaginationRow('expiring', 1, Math.ceil(todayExpiring.length / 10)),
              ...interaction.message.components
            ]
          });
        }
        break;
      }
      case 'help': {
        await interaction.editReply({
          embeds: [createHelpEmbed()],
          components: interaction.message.components
        });
        break;
      }
      case 'refresh': {
        const listType = interaction.message.content.toLowerCase().includes('public') ? 'public' : 'private';
        const refreshedWorlds = await getWorlds(
          listType === 'public' ? null : interaction.user.id,
          listType === 'public'
        );
        const refreshedTable = formatWorldsTable(refreshedWorlds, 1, 10, listType);
        const buttons = listType === 'public' ? createPublicListButtons() : createPrivateListButtons();

        await interaction.editReply({
          content: refreshedTable,
          components: buttons
        });
        break;
      }
      default:
        throw new Error('Unknown command type');
    }
  } catch (error) {
    throw new Error(`Command button error: ${error.message}`);
  }
}

// Update the main interaction handler (unchanged except for filter button handling)
client.on('interactionCreate', async interaction => {
  try {
    if (interaction.isCommand() && interaction.commandName === 'list') {
      const welcomeEmbed = new EmbedBuilder()
        .setTitle('🌟 Welcome to Growtopia World Tracker')
        .setColor(0x0099FF)
        .setDescription('Track your Growtopia worlds and their expiration dates!')
        .addFields(
          { name: '📝 Choose Your List', value: 'Select which list you want to view:' },
          { name: '🔒 Private List', value: 'Your personal world tracking list', inline: true },
          { name: '🌐 Public List', value: 'Community shared worlds', inline: true }
        )
        .setTimestamp();

      await interaction.reply({
        embeds: [welcomeEmbed],
        components: [createListTypeButtons()],
        ephemeral: true
      });
    } else if (interaction.isButton()) {
      if (interaction.customId.startsWith('confirm_remove_')) {
        const worldName = interaction.customId.split('_')[2];
        const result = await safeExecuteDBOperation(
          async () => await removeWorld(worldName, interaction.user.id),
          'Failed to remove world.',
          interaction
        );

        if (result.success) {
          await interaction.update({
            embeds: [createSuccessEmbed('✅ World Removed', 
              `World "${worldName}" has been removed from your tracking list.`)],
            components: []
          });
        }
      } else if (interaction.customId === 'cancel_remove') {
        await interaction.update({
          embeds: [createInfoEmbed('🚫 Action Cancelled', 
            'The world removal operation was cancelled.\nYour world remains in the tracking list.')],
          components: []
        });
      } else if (interaction.customId === 'auto_refresh') {
        await handleAutoRefresh(interaction);
      } else if (interaction.customId === 'filter_clear') {
        await handleClearFilter(interaction);
      } else if (interaction.customId === 'filter_apply'){
        await handleFilterApply(interaction);
      } else {
        await handleButtonInteraction(interaction);
      }
    } else if (interaction.isModalSubmit()) {
      await handleModalSubmit(interaction);
    }
  } catch (error) {
    console.error('Interaction error:', error);
    await handleError(interaction, error);
  }
});


// Add helper functions for filter UI
function createClearFilterButton() {
  return new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('filter_clear')
        .setLabel('🔄 Show All Worlds')
        .setStyle(ButtonStyle.Primary)
    );
}

function createActiveFilterRow(filterType, filterValue) {
  return new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('clear_filter')
        .setLabel('❌ Clear Filter')
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('filter_info')
        .setLabel(`🔍 Active: ${filterType} = ${filterValue}`)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );
}

// Add function to handle clear filter action
async function handleClearFilter(interaction) {
  await interaction.deferUpdate();
  const listType = interaction.message.content.toLowerCase().includes('public') ? 'public' : 'private';
  const userId = listType === 'public' ? null : interaction.user.id;
  const worlds = await getWorlds(userId, listType === 'public');
  const table = formatWorldsTable(worlds, 1, 10, listType);
  const buttons = listType === 'public' ? createPublicListButtons() : createPrivateListButtons();

  await interaction.editReply({ content: table, components: buttons });
}

// Update the world action buttons with improved layout
function createWorldActionButtons(worldName, isPublic = false) {
  const row1 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`share_${worldName}`)
        .setLabel(isPublic ? 'Make Private' : 'Make Public')
        .setStyle(isPublic ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`edit_${worldName}`)
        .setLabel('Edit Days')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`remove_${worldName}`)
        .setLabel('Remove')
        .setStyle(ButtonStyle.Danger)
    );

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`info_${worldName}`)
        .setLabel('World Info')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`refresh_${worldName}`)
        .setLabel('🔄 Refresh')
        .setStyle(ButtonStyle.Secondary)
    );

  return [row1, row2];
}

// Add function to check expiring worlds
function checkExpiringWorlds(worlds) {
  const currentDate = getCurrentDateInTimeZone();
  return worlds.filter(world => {
    const expirationDate = addDays(startOfDay(currentDate), 180 - world.days_owned);
    return world.days_owned >= 180 || isSameDay(expirationDate, currentDate);
  });
}

// Add enhanced error handling for database operations (unchanged)
async function safeExecuteDBOperation(operation, errorMessage, interaction) {
  try {
    const result = await operation();
    return { success: true, result };
  } catch (error) {
    console.error('Database operation error:', error);

    let userMessage = errorMessage;
    if (error.message.includes('UNIQUE constraint failed')) {
      userMessage = 'This world already exists in your tracking list.';
    } else if (error.message.includes('database is locked')) {
      userMessage = 'The system is busy. Please try again in a moment.';
    } else if (error.message.includes('no such table')) {
      userMessage = 'There was a problem with the database. Please try again later.';
    }

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ embeds: [createErrorEmbed('❌ Database Error', userMessage)], ephemeral: true });
    } else {
      await interaction.reply({ embeds: [createErrorEmbed('❌ Database Error', userMessage)], ephemeral: true });
    }

    return { success: false, error };
  }
}

// Add auto-refresh handler (unchanged)
async function handleAutoRefresh(interaction) {
  await interaction.deferUpdate();
  const listType = interaction.message.content.includes('PUBLIC') ? 'public' : 'private';
  const worlds = await getWorlds(listType === 'public' ? null : interaction.user.id, listType === 'public');
  const table = formatWorldsTable(worlds, 1, 10, listType);

  await interaction.editReply({
    content: table,
    components: interaction.message.components
  });
}

// Login (unchanged)
client.login(token).catch(error => {
  console.error('Failed to connect to Discord:', error.message);
  process.exit(1);
});

// Update the validation handling function with better examples and messages (unchanged)
async function handleModalValidation(interaction, worldName, daysOwned) {
  const validationErrors = [];
  const examples = {
    world_name: ['ABC', 'BUY123', 'SELL+WOOD'],
    days_owned: ['0', '30', '180']
  };

  // World name validation
  if (!worldName || worldName.length < 1) {
    validationErrors.push(`❌ World name cannot be empty\n📝 Example: ${examples.world_name[0]}`);
  } else if (worldName.length > 20) {
    validationErrors.push(`❌ World name too long (max 20 characters)\n📝 Example: ${examples.world_name[0]}`);
  } else if (!/^[A-Z0-9+]+$/.test(worldName)) {
    validationErrors.push(`❌ Invalid characters used\n✅ Format: Letters, numbers, and + symbol only\n📝 Examples: ${examples.world_name.join(', ')}`);
  }

  // Days owned validation
  if (isNaN(daysOwned)) {
    validationErrors.push(`❌ Days owned must be a number\n📝 Examples: ${examples.days_owned.join(', ')}`);
  } else if (daysOwned < 0) {
    validationErrors.push(`❌ Days owned cannot be negative\n✅ Minimum: 0 days`);
  } else if (daysOwned > 180) {
    validationErrors.push(`❌ Days owned cannot exceed 180\n✅ Maximum: 180 days`);
  }

  if (validationErrors.length > 0) {
    const errorEmbed = new EmbedBuilder()
      .setTitle('❌ Invalid Input')
      .setColor(0xFF0000)
      .setDescription('Please fix the following issues:')
      .addFields(
        validationErrors.map(error => ({
          name: '•',
          value: error
        }))
      )
      .setFooter({ text: 'Click the button again to try again' });

    if (interaction.deferred) {
      await interaction.editReply({ embeds: [errorEmbed] });
    } else {
      await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
    return false;
  }

  return true;
}

// Update modal submit handler (unchanged except for filter modal handling)
async function handleModalSubmit(interaction) {
  try {
    const modalId = interaction.customId;
    const worldName = interaction.fields.getTextInputValue('world_name').toUpperCase();

    // Defer reply for all modal submissions except filter
    if (!modalId.includes('filter')) {
      await interaction.deferReply({ ephemeral: true });
    }

    switch (modalId) {
      case 'add_world_modal': {
        const daysOwned = parseInt(interaction.fields.getTextInputValue('days_owned'));

        // Validate input with enhanced messages
        if (!await handleModalValidation(interaction, worldName, daysOwned)) {
          return;
        }

        const addWorldOperation = async () => await addWorld(worldName, daysOwned, interaction.user.tag, interaction.user.id);
        const result = await safeExecuteDBOperation(addWorldOperation, 'Failed to add world.', interaction);

        if (result.success) {
          const embed = createWorldAddedEmbed(worldName, daysOwned);
          await interaction.editReply({
            embeds: [embed],
            components: createWorldActionButtons(worldName, false)
          });
        }
        break;
      }

      case 'remove_world_modal': {
        // Add confirmation dialog for remove action
        const confirmEmbed = createConfirmationEmbed('remove', worldName);
        const confirmButtons = createConfirmationButtons('remove', worldName);

        await interaction.editReply({
          embeds: [confirmEmbed],
          components: [confirmButtons]
        });
        break;
      }

      case 'share_world_modal': {
        const shareOperation = async () => await updateWorldPublicStatus(worldName, interaction.user.id, 1);
        const result = await safeExecuteDBOperation(shareOperation, 'Failed to share world.', interaction);

        if (result.success) {
          await interaction.editReply({
            embeds: [createSuccessEmbed('🌐 World Shared', 
              `World "${worldName}" is now public and visible to everyone.`)]
          });
        }
        break;
      }

      case 'unshare_world_modal': {
        const unshareOperation = async () => await updateWorldPublicStatus(worldName, interaction.user.id, 0);
        const result = await safeExecuteDBOperation(unshareOperation, 'Failed to unshare world.', interaction);

        if (result.success) {
          await interaction.editReply({
            embeds: [createSuccessEmbed('🔒 World Privacy Updated', 
              `World "${worldName}" is now private.`)]
          });
        }
        break;
      }
      case 'filter_world_modal': {
        await handleFilterModalSubmit(interaction);
        return;
      }
      default:
        await interaction.reply({
          embeds: [createErrorEmbed('❌ Unknown Modal', 
            'This modal type is not recognized. Please try a different action.')],
          ephemeral: true
        });
    }
  } catch (error) {
    console.error('Modal submit error:', error);
    const errorMessage = error.message.includes('UNIQUE constraint') 
      ? 'This world already exists in your list.'
      : 'An error occurred while processing your request. Please try again.';

    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        embeds: [createErrorEmbed('❌ Error', errorMessage)],
        ephemeral: true
      });
    } else {
      await interaction.editReply({
        embeds: [createErrorEmbed('❌ Error', errorMessage)]
      });
    }
  }
}

// Add function to delete expired worlds
async function cleanupExpiredWorlds() {
  return new Promise((resolve, reject) => {
    console.log('Starting expired worlds cleanup...');
    db.run(
      'DELETE FROM worlds WHERE days_owned >= 181',
      function(err) {
        if (err) {
          console.error('Error cleaning up expired worlds:', err);
          reject(err);
        } else {
          if (this.changes > 0) {
            console.log(`Successfully removed ${this.changes} expired world(s) (181+ days)`);
          } else {
            console.log('No expired worlds found to clean up');
          }
          resolve(this.changes);
        }
      }
    );
  });
}

// Improve error handling function
async function handleError(interaction, error, message = 'An error occurred while processing your request.') {
  console.error('Error:', error);
  let errorMessage = message;

  // Provide more specific error messages based on error type
  if (error.message.includes('Unknown Modal')) {
    errorMessage = 'This button action is not yet implemented. Please try another option.';
  } else if (error.message.includes('Unknown Interaction')) {
    errorMessage = 'This action cannot be processed right now. Please try again later.';
  } else if (error.message.includes('InteractionAlreadyReplied\n";

  // Header
  table += `${listType.toUpperCase()} LIST`;
  if (activeFilter) {
    table += ` (Filtered by ${activeFilter.type}: ${activeFilter.value})`;
  }
  table += "\n" + "─".repeat(80) + "\n";

  // Expiring worlds alert
  const expiringWorlds = checkExpiringWorlds(worlds);
  if (expiringWorlds.length > 0) {
    table += `⚠️ ${expiringWorlds.length} world${expiringWorlds.length === 1 ? ' is' : 's are'} expiring today!\n`;
    table += "─".repeat(80) + "\n";
  }

  // Column headers
  table += "No | World Name | Expiry Date | Days Owned | Days Left | Letters | Added By\n";
  table += "─".repeat(80) + "\n";

  // World rows
  const startIdx = (page - 1) * pageSize;
  const endIdx = Math.min(startIdx + pageSize, worlds.length);
  const pagedWorlds = worlds.slice(startIdx, endIdx);

  pagedWorlds.forEach((world, index) => {
    const rowNum = startIdx + index + 1;
    const addedByDisplay = world.added_by.split('#')[0];
    const expirationStatus = world.days_owned >= 180 ? '🚨' : 
                           world.days_left <= 7 ? '❗' : 
                           world.days_left <= 30 ? '⚠️' : ' ';

    table += [
      rowNum.toString().padEnd(3),
      world.world_name.padEnd(12),
      world.expiration_date.padEnd(12),
      world.days_owned.toString().padEnd(11),
      `${expirationStatus} ${world.days_left.toString().padEnd(8)}`,
      world.letter_count.toString().padEnd(8),
      addedByDisplay
    ].join('| ') + "\n";
  });

  // Footer
  table += "─".repeat(80) + "\n";
  table += `Page ${page}/${Math.ceil(worlds.length / pageSize)} - Total: ${worlds.length} worlds\n`;
  table += "🚨 = Expired/Expiring today | ❗ = Within 7 days | ⚠️ = Within 30 days\n";
  table += "